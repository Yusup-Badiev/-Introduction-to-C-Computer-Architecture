#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
	int data;
	struct node *left;
	struct node *right;
}nodeT;

nodeT* add(struct node* head, struct node* newNode) 
{
	if(head == NULL)
		return newNode;

	if(head->data > newNode->data){
		head->left =  add(head->left, newNode);
	}

	if(head->data < newNode->data){
		head->right = add(head->right, newNode);
	}

	return head;
}

void printTree(struct node* head) 
{
	if(head==NULL)
		return;
	printTree(head->left);
	printf("%d	", head->data);
	printTree(head->right);
}

void FreeAll(struct node* head)
{
        if(head==NULL)
                return;
        FreeAll(head->left);
        FreeAll(head->right);
	free(head);
}

int main(int argr, char **argv)
{
	FILE *ptrFile;
	char Command;
	int HoldVal;
	nodeT *Front;
	Front = (nodeT *) malloc(sizeof(nodeT));
	Front->left = NULL;
	Front->right = NULL;
	int first = 0;
	
	ptrFile = fopen(argv[1], "r");
	if(ptrFile == NULL){
		printf("error");
		return 0;
	}
	while(!feof(ptrFile)){
		fscanf(ptrFile, "%c", &Command);
		fscanf(ptrFile, "%d", &HoldVal);
		if(Command == 'i'){
			if(first == 0){
				Front->data = HoldVal;
				first = 1;
			}
			else{
				nodeT *Holder;
				Holder = (nodeT *) malloc(sizeof(nodeT));
				Holder->data = HoldVal;
				Holder->left = NULL;
				Holder->right = NULL;
 				add(Front, Holder);
			}
          	}
	}
	printTree(Front);
	FreeAll(Front);
	fclose(ptrFile);
}
