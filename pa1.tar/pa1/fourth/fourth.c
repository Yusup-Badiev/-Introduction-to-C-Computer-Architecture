#include <stdio.h>


int main (int argc, char *argv[])
{
	FILE *ptr_file;
	ptr_file = fopen(argv[1],"r");
	int H1;
	int W1;
	int H2;
	int W2;
	int Counter1;
	int Counter2;
	int holder;
	int i = 0;
	
	fscanf(ptr_file, "%d", &H1);
	fscanf(ptr_file, "%d", &W1);
	Counter1 = H1*W1;
	for (i = 0; i < Counter1; i++){
		fscanf(ptr_file, "%d", &holder);
	}
	fscanf(ptr_file, "%d", &H2);
        fscanf(ptr_file, "%d", &W2);
	Counter2 = H2*W2;
	int Matrix1[Counter1];
        int Matrix2[Counter2];
	
	rewind(ptr_file);
	
	fscanf(ptr_file, "%d", &holder);
        fscanf(ptr_file, "%d", &holder);
	
	for (i = 0; i < Counter1; i++){
                fscanf(ptr_file, "%d", &Matrix1[i]);
        }
	
	fscanf(ptr_file, "%d", &holder);
        fscanf(ptr_file, "%d", &holder);
	
	for (i = 0; i < Counter2; i++){
                fscanf(ptr_file, "%d", &Matrix2[i]);
        }
	
	fclose(ptr_file);

	if(W1 != H2){
		printf("bad-matrices");
		return 0;
	}
	
	int H3 = H1;
	int W3 = W2;
	int Counter3 = H3*W3;
	int j;
	int countNew = 0;
	int Matrix3[Counter3];
	int TempSum;
	
	int Matrix2New[Counter2];
	for(i = 0; i<W2; i++){
		for(j = 0+i; j < Counter2; j=j+W2){
			Matrix2New[countNew] = Matrix2[j];
			countNew++;
		}
	}
	
	for(i = 0; i < Counter3; i++){
		TempSum = 0;
		int RowM1 = (i)/W3;
		int RowM2 = (i)%W3;
		for(j = 0; j < W1; j++){
			TempSum = TempSum + (Matrix1[j+RowM1*W1] * Matrix2New[j+RowM2*W1]);
		}
		Matrix3[i] = TempSum;
	}
	int First = 0;
	for(i = 0; i < Counter3; i++){
		if(i%W3 == 0 && First == 1){
			printf("\n");
		}
		First = 1;
                printf("%d	" ,Matrix3[i]);
        }
}
