#include <stdio.h>

int main(int argc, char **argv)
{
    int count;
    int checkedLen = 0;
    int position;
    int count3;
    int sortedFinalCounter=0;
    int c;
    int c2;
    int c3;
    int dataCounter = 0;
    int Fcount;
    int sortCounter = 0;

    int len;
    int data[21];

    FILE *ptr_file;
    ptr_file = fopen(argv[1],"r");
    fscanf(ptr_file, "%d", &len);
    for (Fcount = len; Fcount>0; Fcount--) {
        fscanf(ptr_file, "%d", &data[dataCounter]);
        dataCounter++;
    }

    int dlen = len;
    int sorted[21];
    int sortedFinal[21];
    
    while(checkedLen != len){
        int hold = data[dlen-1];
        position = dlen-1;
        for(count = dlen-2; count>=0; count--){
            if(hold > data[count]){
                hold = data[count];
                position = count;
            }
        }
        sorted[sortCounter]=hold;
        for(count3=position; count3<=dlen-2; count3++){
            data[count3]=data[count3+1];
        }
        dlen--;
        checkedLen++;
        sortCounter++;
    }
    for(c=0;c<=len-1;c++){
        if(sorted[c]%2==0){
            sortedFinal[sortedFinalCounter] = sorted[c];
            sortedFinalCounter++;
        }
    }
    for(c2=len-1;c2>=0;c2--){
        if(sorted[c2]%2!=0){
            sortedFinal[sortedFinalCounter] = sorted[c2];
            sortedFinalCounter++;
        }
    }

    for(c3=0;c3<=sortedFinalCounter-2;c3++){
        printf("%d	",sortedFinal[c3]);
    }
    
    printf("%d",sortedFinal[sortedFinalCounter-1]);
    fclose(ptr_file);
}
