#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
	int data;
	struct node *next;
}nodeT;

void add(struct node** head, struct node* newNode) 
{
	if (*head == NULL || (*head)->data >= newNode->data){
		newNode->next = *head;
		*head = newNode;
		return;
	}
	struct node* current = *head;
	while(current->next != NULL && current->next->data < newNode->data)
		current = current->next;
	
	newNode->next = current->next;
	current->next = newNode;
}

void removeN(struct node** head, int  remove){
	if ((*head)->data == remove){
		struct node* Temp = (*head)->next;
		free(*head);
                *head = Temp;
                return;
        }
	
        struct node* current = *head;
        while(current->next->data != remove)
		current = current->next;
	
	struct node* CNN = current->next->next;
	free(current->next);
        current->next = CNN;
}

int index(struct node** head, int target){
        struct node* current = *head;
	int counter = 0;
        while(current != NULL && current->data != target){
                current = current->next;
		counter++;
	}
	
	if(current == NULL)
		return -1;
	return counter;
}

void FreeAll(struct node* head){
	if(head == NULL)
		return;
	else{
		FreeAll(head->next);
	}
	free(head);
}

int main(int argr, char **argv){
	FILE *ptrFile;
	char Command;
	int HoldVal;
	int size=0;
	nodeT *Front;
	Front = (nodeT *) malloc(sizeof(nodeT));
	int counter = 0;
	ptrFile = fopen(argv[1], "r");
	while(!feof(ptrFile)){
		counter++;
		fscanf(ptrFile, "%c", &Command);
		fscanf(ptrFile, "%d", &HoldVal);
		if(Command == 'i'){
			nodeT *Holder;
			Holder = (nodeT *) malloc(sizeof(nodeT));
			Holder->data = HoldVal;
 			add(&(Front->next), Holder);
			size++;
          	}
                if(Command == 'd'){
			int I = index(&Front, HoldVal);
			if(I != -1){
				size--;
				removeN(&(Front->next), HoldVal);	
			}
                }
	}
	printf("%d", size);
	printf("\n");
	nodeT *Front1 = Front->next;
	int hold;
	int first = 1;
	while(Front1!=NULL){
		if(first == 1){
			printf("%d",Front1->data);
		}
		if(first == 0 && Front1->data != hold){
			printf("	%d",Front1->data);
		}
		first = 0;
		hold = Front1->data;
		Front1 = Front1->next;
	}
	FreeAll(Front->next);
	free(Front);
	fclose(ptrFile);
}
