#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
	int data;
	struct node *next;
}nodeT;

int incert(nodeT* Hashtable[], nodeT* Holder){
	int re = 0;
	if(Holder->data < 0){
		if(Hashtable[(((Holder->data))+10000)%10000] != NULL){
			re = 1;
		}
		Holder->next = Hashtable[(((Holder->data)+10000))%10000];
		Hashtable[((Holder->data)+10000)%10000] = Holder;
	}
	else{
		if(Hashtable[(Holder->data)%10000] != NULL){
			re = 1;
		}
		Holder->next = Hashtable[(Holder->data)%10000];
		Hashtable[(Holder->data)%10000] = Holder;
	}
	return re;
}

void FreeAll(nodeT* head){
	if(head == NULL)
		return;
	else{
		FreeAll(head->next);
	}
	free(head);
}

int search(nodeT* Position ,int Target){
	while(Position != NULL){
		if(Position->data == Target){
			return 1;
		}
	Position = Position->next;
	}
	return 0;
}

int main(int argr, char **argv){
	FILE *ptrFile;
	ptrFile = fopen(argv[1], "r");
	nodeT* Hashtable[10000];
	for(int i = 0; i < 10000; i++)
		Hashtable[i] = NULL;
	int CollisCounter = 0;
	int Fcount = 0;
	char Command;
	int HoldVal;
	while(!feof(ptrFile)){
		fscanf(ptrFile, "%c", &Command);
		fscanf(ptrFile, "%d", &HoldVal);
		if(Command == 'i'){
			nodeT *Holder;
			Holder = (nodeT *) malloc(sizeof(nodeT));
			Holder->data = HoldVal;
			int Colision = incert(Hashtable, Holder);
			if (Colision == 1){
				CollisCounter++;
			}
		}
		if(Command == 's'){
			int found = 0;
			if(HoldVal < 0){
				found = search(Hashtable[(HoldVal+10000)%10000], HoldVal);
			}
			else{
				found = search(Hashtable[HoldVal%10000], HoldVal);	
			}
			if(found == 1){
				Fcount++;
			}
		}
	}
	printf("%d\n", CollisCounter);
	printf("%d", Fcount);
	for(int m = 0; m < 10000; m++){
        	if(Hashtable[m] != NULL)
			FreeAll(Hashtable[m]);
	}
	fclose(ptrFile);
}
