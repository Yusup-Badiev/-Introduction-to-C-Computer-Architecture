#include <stdio.h>

int main(int argc, char **argv)
{	
	int a = 0;
	char Holder;
	for(int b = 1; b < argc; b++){
		Holder = argv[b][a];
		while(Holder != 0){
			if(Holder == 'a' || Holder == 'e' || Holder == 'i' || Holder == 'o' || Holder == 'u' || Holder== 'A' || Holder == 'E' || Holder == 'I' || Holder == 'O' || Holder == 'U'){
				printf("%c", Holder);		
			}
			a++;
			Holder = argv[b][a];
		}
		a=0;
	}
}
